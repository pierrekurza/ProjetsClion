#ifndef	SCENE_HPP
#define SCENE_HPP

#include <iostream>
#include <SFML/Graphics.hpp>

using namespace std;

class Scene
{
private:
	sf::CircleShape							_mesCercles;
	sf::RectangleShape         	_square;
	vector<sf::CircleShape>		_circles;

public:
	Scene(const sf::Vector2u& v) :
		_square(),
		_circles(),
		_mesCercles()
	{

		_square.setSize(sf::Vector2f(800,600));
		_square.setFillColor(sf::Color::Magenta);
			for(int i = 0; i < 2; i++)
			{
				for(int j = 0; j < 2; j++)
				{
						_mesCercles.setRadius(200);
						_mesCercles.setPosition(300 + (i*300), 300 + (j*300));
						_mesCercles.setFillColor(sf::Color::Black);
						_circles.push_back(_mesCercles);
				}
			}


	}

	~Scene()
	{}

	void setOriginToCenter(sf::Shape& shape)
	{
		sf::FloatRect boundingBox = shape.getLocalBounds();
		shape.setOrigin(boundingBox.left + boundingBox.width/2.0f, boundingBox.top  + boundingBox.height/2.0f);
	}

	void processEvent(const sf::Event& event)
	{
	}

	void update()
	{
	}

	void draw(sf::RenderWindow& window)
	{
		window.clear();
		window.draw(_square);
		for(int i =0; i < _circles.size(); i++)
			window.draw(_circles[i]);
		window.display();
	}
};

#endif
