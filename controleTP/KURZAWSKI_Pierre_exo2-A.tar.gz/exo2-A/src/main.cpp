#include "application.hpp"

int main()
{
	Application app;
	app.run();
}
