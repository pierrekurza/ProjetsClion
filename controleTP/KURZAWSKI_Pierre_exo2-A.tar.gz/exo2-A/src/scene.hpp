#ifndef	SCENE_HPP
#define SCENE_HPP

#include <iostream>
#include <SFML/Graphics.hpp>

using namespace std;

class Scene
{
private:
	sf::RectangleShape         	_square;
	sf::CircleShape							_mesCercles;
	vector<sf::CircleShape>		_circles;

public:
	Scene(const sf::Vector2u& v) :
		_square(),
		_circles()
	{
		_square.setSize(sf::Vector2f(200,200));
		_square.setPosition(v.x, v.y);
		_square.setFillColor(sf::Color::Transparent);
		setOriginToCenter(_square);

		for(int i = 0; i < 2; i++)
		{
				for(int j = 0; j < 2; j++)
				{
					_mesCercles.setRadius(100);
					_mesCercles.setOutlineColor(sf::Color::Green);
					_mesCercles.setFillColor(sf::Color::Transparent);
					_mesCercles.setOutlineThickness(3.0);
					_mesCercles.setPosition(200 + (i*200), 200 + (j*200));
					_circles.push_back(_mesCercles);
				}
}
	}

	~Scene()
	{}

	void setOriginToCenter(sf::Shape& shape)
	{
		sf::FloatRect boundingBox = shape.getLocalBounds();
		shape.setOrigin(boundingBox.left + boundingBox.width/2.0f, boundingBox.top  + boundingBox.height/2.0f);
	}

	void processEvent(const sf::Event& event)
	{
	}

	void update()
	{
	}

	void draw(sf::RenderWindow& window)
	{
		window.clear();
		window.draw(_square);
		for(int i =0; i < _circles.size(); i++)
			window.draw(_circles[i]);
		window.display();
	}
};

#endif
